package com.angrybird1;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class gamescreen implements Screen {
    //screen
    private Camera camera;
    private Viewport viewport;
    // graphics
    private SpriteBatch batch;
    private Texture background;
    private ShapeRenderer shapeRenderer;
    //timing
    private int backgroundOffset;
    //bar
    private float loadingProgress;
    //world parameters
    private final int WORLD_WIDTH=1200;
    private final int WORLD_HEIGHT=1000;
    gamescreen(){
        camera= new OrthographicCamera();
        viewport = new StretchViewport(WORLD_WIDTH,WORLD_HEIGHT,camera);
        camera.position.set(WORLD_WIDTH / 2f, WORLD_HEIGHT / 2f, 0);
        camera.update();

        background = new Texture(Gdx.files.internal("ang1.png"));

        backgroundOffset = 0;
        batch = new SpriteBatch() ;
        shapeRenderer = new ShapeRenderer();



    }


    @Override
    public void show() {


    }

    @Override
    public void render(float deltaTime) {
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.draw(background, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);
        batch.end();
        loadingProgress += deltaTime * 0.1f; // Simulate loading progress
        if (loadingProgress > 1.0f) {
            loadingProgress = 1.0f;
        }
        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.WHITE); // Color of the loading bar

        // Draw the background of the loading bar
        shapeRenderer.rect((WORLD_WIDTH - 400) / 2, 50, 400, 20); // Background of loading bar
        shapeRenderer.setColor(Color.GOLD); // Color of the loading progress
        shapeRenderer.rect((WORLD_WIDTH - 400) / 2, 50, 400 * loadingProgress, 20); // Progress of loading bar

        shapeRenderer.end();
    }



    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
        batch.setProjectionMatrix(camera.combined);

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
