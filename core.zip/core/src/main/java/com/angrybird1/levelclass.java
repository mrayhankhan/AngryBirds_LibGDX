package com.angrybird1;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class levelclass implements Screen {
    private Texture backgroundImage;
    private Main main;
    private Stage stage;
    private Skin skin;

    // Difficulty levels
    private static final String[] DIFFICULTY_LEVELS = {"Easy", "Medium", "Hard"};

    public levelclass(Main main, Skin skin) {
        this.main = main;
        this.skin = skin;
        this.setupStage();
        this.setupDifficultyButtons();
    }

    private void setupStage() {
        this.stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(this.stage);
    }

    private void setupDifficultyButtons() {
        this.createBackButton(skin);
        this.createDifficultyButtons(skin);
    }

    private void createDifficultyButtons(Skin skin) {
        Table table = new Table();
        table.setFillParent(true);
        this.stage.addActor(table);

        for (String difficulty : DIFFICULTY_LEVELS) {
            TextButton lvlButton = new TextButton(difficulty, skin);
            lvlButton.addListener((event) -> {
                if (lvlButton.isPressed()) {
                    this.showLevelsForDifficulty(difficulty);
                }
                return true;
            });
            table.defaults().width(300.0F).height(100.0F).pad(50.0F);
            table.add(lvlButton);
            table.row();  // Move to next row after each button
        }
    }

    private void createBackButton(Skin skin) {
        TextButton backButton = new TextButton("<", skin);
        this.stage.addActor(backButton);
        backButton.setHeight(70.0F);
        backButton.setWidth(70.0F);
        backButton.setPosition(50.0F, 950.0F);
        backButton.addListener((event) -> {
            if (backButton.isPressed()) {
                main.setScreen(main.mainMenuScreen);
            }
            return true;
        });
    }

    // Method to show levels 1, 2, 3 after selecting a difficulty
    private void showLevelsForDifficulty(String difficulty) {
        stage.clear();  // Clear the stage to remove difficulty buttons

        Table table = new Table();
        table.setFillParent(true);
        this.stage.addActor(table);

        // Create 3 level buttons with generic names "Level 1", "Level 2", "Level 3"
        for (int i = 1; i <= 3; i++) {
            TextButton lvlButton = new TextButton("Level " + i, skin);
            int lvlNum = i;  // Capture level number for use in listener
            lvlButton.addListener((event) -> {
                if (lvlButton.isPressed()) {
                    this.startLevel(difficulty, lvlNum);
                }
                return true;
            });
            table.defaults().width(150.0F).height(100.0F).pad(50.0F);
            table.add(lvlButton);
            table.row();
        }

        // Add a back button to return to difficulty selection
        TextButton backButton = new TextButton("<", skin);
        backButton.setHeight(70.0F);
        backButton.setWidth(70.0F);
        backButton.addListener((event) -> {
            if (backButton.isPressed()) {
                stage.clear();  // Clear levels and show difficulty buttons again
                this.setupDifficultyButtons();
            }
            return true;
        });
        stage.addActor(backButton);
    }


    public void startLevel(String difficulty, int lvlNum) {
        if (difficulty.equals("Easy") && lvlNum == 1) {
            main.setScreen(new com.angrybird1.gameScreenlevel(main));  // Switch to gameScreenlevel
        }
        // You can add conditions for other difficulty levels and levels here
    }

    @Override
    public void show() {}

    @Override
    public void render(float v) {
        Gdx.gl.glClear(16384);
        this.main.spriteBatch.begin();
        // this.main.spriteBatch.draw(this.backgroundImage, 0.0F, 0.0F);
        this.main.spriteBatch.end();
        this.stage.act();
        this.stage.draw();
    }

    @Override
    public void resize(int i, int i1) {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        this.stage.dispose();
        if (this.backgroundImage != null) this.backgroundImage.dispose();
    }
}
