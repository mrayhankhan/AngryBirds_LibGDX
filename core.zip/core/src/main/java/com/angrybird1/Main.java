package com.angrybird1;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

import java.time.Duration;
import java.time.LocalTime;

public class Main extends Game {
    private final static Assets assets = new Assets();
    MainMenuScreen mainMenuScreen;
    gamescreen gameScreen;
    public static SpriteBatch spriteBatch;
    private LocalTime startTime;
    private boolean isGameScreenActive;



    @Override
    public void create() {
        Assets assets = new Assets();
        assets.loadAll();
        assets.getAssetManager().finishLoading();

        Skin skin = assets.getAssetManager().get(Assets.SKIN);  // Get skin

        levelclass levelScreen = new levelclass(this, skin);  // Pass skin to levelclass
        setScreen(levelScreen);
        spriteBatch = new SpriteBatch();

        // Load assets
        assets.loadAll();
        assets.getAssetManager().finishLoading();

        // Initialize screens
        gameScreen = new gamescreen();  // Pass assets to game screen
        mainMenuScreen = new MainMenuScreen(assets.getAssetManager(), this);  // Pass AssetManager to MainMenuScreen

        // Set initial screen and start time
        setScreen(gameScreen);
        startTime = LocalTime.now();
        isGameScreenActive = true;  // Flag to track active screen


    }

    @Override
    public void render() {
        Duration timeElapsed = Duration.between(startTime, LocalTime.now());

        // Switch to main menu after 5 seconds, but only once
        if (timeElapsed.getSeconds() > 5 && isGameScreenActive) {
            setScreen(mainMenuScreen);  // Switch to MainMenuScreen after 5 seconds
            isGameScreenActive = false;  // Prevent further switching
        }

        // Call parent render method to render the current screen
        super.render();
    }

    @Override
    public void dispose() {
        // Dispose resources
        spriteBatch.dispose();
        gameScreen.dispose();
        mainMenuScreen.dispose();
    }

    public Assets getAssets(){
        return assets;
    }
}
