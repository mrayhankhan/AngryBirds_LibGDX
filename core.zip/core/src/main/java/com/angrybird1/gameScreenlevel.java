package com.angrybird1;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class gameScreenlevel implements Screen {
    private Main main;
    private OrthographicCamera camera;
    private SpriteBatch batch;
    private Texture background;

    private Bird bird;
    private Pig pig;
    private Block[] blocks;


    public gameScreenlevel(Main main) {
        this.main = main;
        ScreenViewport viewport = new ScreenViewport();
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 3080, 2000);
        viewport.setCamera(camera);
        batch = new SpriteBatch();

        background = new Texture(Gdx.files.internal("background.png"));
        bird = new Bird(75, 100, 400, 400);
        pig = new Pig(1000, 350, 200, 200);
        blocks = new Block[] {
            new Block(1000, 150, 200, 200),
            new Block(1200, 150, 200, 200),
            new Block(1200, 350, 200, 200)
        };
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        batch.setProjectionMatrix(camera.combined);

        batch.begin();
        batch.draw(background, 0, 0, 1920,1080);
        bird.render(batch);
        pig.render(batch);
        for (Block block : blocks) {
            block.render(batch);
        }
        batch.end();
    }

    @Override
    public void resize(int width, int height) {
        camera.setToOrtho(false, width, height);
    }

    @Override
    public void dispose() {
        background.dispose();
        bird.dispose();
        pig.dispose();
        for (Block block : blocks) block.dispose();
        batch.dispose();
    }

    @Override
    public void show() {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void hide() {}
}
